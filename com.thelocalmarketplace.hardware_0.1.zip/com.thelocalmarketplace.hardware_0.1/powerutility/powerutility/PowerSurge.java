package powerutility;

/**
 * Simulates a power surge.
 */
public class PowerSurge extends RuntimeException {
	private static final long serialVersionUID = -3127157849326759714L;
}
